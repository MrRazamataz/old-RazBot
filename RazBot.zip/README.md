# RazBot
A Discord bot written in discord.py
The RazBot website can be found at https://razbot.xyz/  
This contains infomation such as *most* of the commands that the Bot has, and an invite link.
Updates come out when I make them.


### Docs:
You can view the start for the (outdated) docs here: https://github.com/MrRazamataz/RazBot/blob/main/docs/RazBotDocs.md


## Suggestions and Bug Reports:  
If you have a suggestion or a bug report for the bot, feel free to open a [GitHub issue](https://github.com/MrRazamataz/RazBot/issues) and put info about it here.  
Alternatively, you can contact me on Discord at `MrRazamataz#6614`.

## Self hosting:  

If you want to self host the bot, you can do if you so wish.
1. Download all of the files of the bot.
2. Install the needed pip packages.
3. Start the `main.py` file and cry that it might not fully work yet.
4. For music, go to `musicconfig.json` and set your spoitify and YouTube API keys.
5. In `music.py`, set your Lavalink server info.
6. wow  

Contact me on discord if you cry too much as its not working.

## Code License  
Do whatever you want with the code, I couldnt care less.
