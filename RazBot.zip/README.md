# RazBot
A Discord bot (meant for KC) written in discord.py
Please find all the info you need on RazBot at: https://mrrazamataz.ga/archive/razbot
Updates come out when I make them.
 
Note: You can view the code and everything you need to such as commands at https://mrrazamataz.ga/archive/razbot!  

### Docs:
You can view the start for the docs here: https://github.com/MrRazamataz/RazBot/blob/main/docs/RazBotDocs.md
